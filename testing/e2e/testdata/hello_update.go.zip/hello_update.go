package main

import "fmt"

func main() {
	toPrint := "hello world updated"
	fmt.Println(toPrint)
}
